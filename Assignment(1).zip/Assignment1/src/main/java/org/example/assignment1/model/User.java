package org.example.assignment1.model;

import jakarta.persistence.*;

import java.time.LocalDate;

@Entity
@Table(name= "users")
public class User {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(unique = true, nullable = false)
    private String username;

    private String password;
    private String role; // "ROLE_USER" or "ROLE_ADMIN"
    private String forename;
    private String surname;
    private String email;
    private String phone;
    private LocalDate birthdate;
    private String address;

    public User() {
        super();
    }
    public User(Long id, String username, String password, String role, String forename, String surname, String email,
                String phone, LocalDate birthdate, String address ) {
        this.id = id;
        this.username = username;
        this.password = password;
        this.role = role;
        this.forename = forename;
        this.surname = surname;
        this.email = email;
        this.phone = phone;
        this.birthdate = birthdate;
        this.address = address;
    }

    public Long getId() {
        return id;
    }
    public void setId(Long id) {
        this.id = id;
    }
    public String getUsername() {
        return username;
    }
    public void setUsername(String username) {
        this.username = username;
    }
    public String getPassword() {
        return password;
    }
    public void setPassword(String password) {
        this.password = password;
    }
    public String getRole() {
        return role;
    }
    public void setRole(String role) {
        this.role = role;
    }
    public void setForename(String forename) {
        this.forename = forename;
    }
    public String getForename() {
        return forename;
    }
    public void setSurname(String surname) {
        this.surname = surname;
    }
    public String getSurname() {
        return surname;
    }
    public void setEmail(String email) {
        this.email = email;
    }
    public String getEmail() {
        return email;
    }
    public void setPhone(String phone) {
        this.phone = phone;
    }
    public String getPhone() {
        return phone;
    }
    public void setDateOfBirth(LocalDate birthdate) {
        this.birthdate = birthdate;
    }
    public LocalDate getDateOfBirth() {
        return birthdate;
    }
    public void setAddress(String address) {
        this.address = address;
    }
    public String getAddress() {
        return address;
    }
}
