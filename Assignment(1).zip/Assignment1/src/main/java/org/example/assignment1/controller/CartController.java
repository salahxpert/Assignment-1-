package org.example.assignment1.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.example.assignment1.model.Book;
import org.example.assignment1.repository.BookRepository;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import jakarta.servlet.http.HttpSession;

import java.math.BigDecimal;
import java.util.*;

@Controller
@RequestMapping("/cart")
public class CartController {

    @Autowired
    private BookRepository bookRepository;

    // Add a book to the cart
    @PostMapping("/add")
    public String addToCart(@RequestParam("bookId") Long bookId,
                            HttpSession session,
                            RedirectAttributes redirectAttributes) {

        Book book = bookRepository.findById(bookId).orElse(null);
        if (book == null) {
            redirectAttributes.addFlashAttribute("errorMessage", "Book not found.");
            return "redirect:/books";
        }

        Map<Long, Integer> cart = (Map<Long, Integer>) session.getAttribute("cart");
        if (cart == null) {
            cart = new HashMap<>();
        }

        int currentQty = cart.getOrDefault(bookId, 0);
        if (currentQty < book.getStock()) {
            cart.put(bookId, currentQty + 1);
            redirectAttributes.addFlashAttribute("successMessage", "Book added to cart!");
        } else {
            redirectAttributes.addFlashAttribute("errorMessage", "Not enough stock available.");
        }

        session.setAttribute("cart", cart);
        return "redirect:/books";
    }

    // Show cart contents
    @GetMapping
    public String showCart(HttpSession session, Model model) {
        Map<Long, Integer> cart = (Map<Long, Integer>) session.getAttribute("cart");
        Map<Book, Integer> cartItems = new LinkedHashMap<>();
        BigDecimal totalPrice = BigDecimal.ZERO;

        if (cart != null) {

            for (Long bookId : cart.keySet()) {
                Book book = bookRepository.findById(bookId).orElse(null);
                if (book != null) {
                    cartItems.put(book, cart.get(bookId));
                    totalPrice = totalPrice.add(book.getPrice().multiply(BigDecimal.valueOf(cart.get(bookId))));
                }
            }
        }

        model.addAttribute("totalPrice", totalPrice);
        model.addAttribute("cartItems", cartItems);
        model.addAttribute("cartQuantities", cart);
        return "cart"; // cart.html should iterate over cartItems.entrySet()
    }

    // Remove item from cart
    @PostMapping("/remove")
    public String removeFromCart(@RequestParam("bookId") Long bookId,
                                 HttpSession session,
                                 RedirectAttributes redirectAttributes) {

        Map<Long, Integer> cart = (Map<Long, Integer>) session.getAttribute("cart");


        if (cart != null) {
            cart.remove(bookId);
            session.setAttribute("cart", cart);
        }

        redirectAttributes.addFlashAttribute("successMessage", "Book removed from cart.");
        return "redirect:/cart";
    }

    @PostMapping("/update")
    public String updateCartQuantities(@RequestParam Map<String, String> allParams,
                                       HttpSession session,
                                       RedirectAttributes redirectAttributes) {

        Map<Long, Integer> cart = (Map<Long, Integer>) session.getAttribute("cart");
        if (cart == null) {
            redirectAttributes.addFlashAttribute("errorMessage", "Cart is empty.");
            return "redirect:/cart";
        }

        boolean hasError = false;
        StringBuilder errorMsg = new StringBuilder();

        for (Map.Entry<String, String> entry : allParams.entrySet()) {
            String rawKey = entry.getKey();
            if (!rawKey.startsWith("quantities[")) continue;

            // Extract book ID
            try {
                String idStr = rawKey.substring(rawKey.indexOf("[") + 1, rawKey.indexOf("]"));
                Long bookId = Long.valueOf(idStr);
                int qty = Integer.parseInt(entry.getValue());

                if (qty < 1) qty = 1;

                Book book = bookRepository.findById(bookId).orElse(null);
                if (book == null) continue;

                if (qty > book.getStock()) {
                    hasError = true;
                    errorMsg.append("Only ")
                            .append(book.getStock())
                            .append(" copies of \"")
                            .append(book.getBook_name())
                            .append("\" available.<br/>");
                    continue;
                }

                cart.put(bookId, qty);

            } catch (NumberFormatException | IndexOutOfBoundsException e) {
                // Ignore malformed input
                continue;
            }
        }

        session.setAttribute("cart", cart);

        if (hasError) {
            redirectAttributes.addFlashAttribute("errorMessage", errorMsg.toString());
        } else {
            redirectAttributes.addFlashAttribute("successMessage", "Cart updated.");
        }

        return "redirect:/cart";
    }

    @GetMapping("/checkout")
    public String showCheckoutPage(HttpSession session, Model model, RedirectAttributes redirectAttributes) {
        Map<Long, Integer> cart = (Map<Long, Integer>) session.getAttribute("cart");

        if (cart == null || cart.isEmpty()) {
            redirectAttributes.addFlashAttribute("errorMessage", "Your cart is empty.");
            return "redirect:/cart";
        }

        Map<Book, Integer> cartItems = new LinkedHashMap<>();
        BigDecimal total = BigDecimal.ZERO;

        for (Map.Entry<Long, Integer> entry : cart.entrySet()) {
            Book book = bookRepository.findById(entry.getKey()).orElse(null);
            if (book != null) {
                cartItems.put(book, entry.getValue());
                total = total.add(book.getPrice().multiply(BigDecimal.valueOf(entry.getValue())));
            }
        }

        model.addAttribute("cartItems", cartItems);
        model.addAttribute("totalPrice", total);

        return "checkout";
    }

    @PostMapping("/checkout")
    public String processCheckout(@RequestParam String cardNumber,
                                  @RequestParam String cardName,
                                  @RequestParam String expiryDate,
                                  @RequestParam String cvv,
                                  HttpSession session,
                                  RedirectAttributes redirectAttributes) {

        Map<Long, Integer> cart = (Map<Long, Integer>) session.getAttribute("cart");
        if (cart == null || cart.isEmpty()) {
            redirectAttributes.addFlashAttribute("errorMessage", "Your cart is empty.");
            return "redirect:/cart";
        }

        // Simulate payment validation
        if (cardNumber.length() < 12 || !cardNumber.replaceAll("\\s", "").matches("\\d+")) {
            redirectAttributes.addFlashAttribute("errorMessage", "Invalid card number.");
            return "redirect:/cart/checkout";
        }

        // Deduct stock for each item
        for (Map.Entry<Long, Integer> entry : cart.entrySet()) {
            Long bookId = entry.getKey();
            int quantity = entry.getValue();

            Book book = bookRepository.findById(bookId).orElse(null);
            if (book != null) {
                int newStock = book.getStock() - quantity;

                if (newStock < 0) {
                    redirectAttributes.addFlashAttribute("errorMessage", "Not enough stock for: " + book.getBook_name());
                    return "redirect:/cart";
                }

                book.setStock(newStock);
                bookRepository.save(book);
            }
        }

        // Clear cart after successful checkout
        session.removeAttribute("cart");

        redirectAttributes.addFlashAttribute("successMessage", "Payment successful! Your order has been placed.");
        return "redirect:/";
    }
}